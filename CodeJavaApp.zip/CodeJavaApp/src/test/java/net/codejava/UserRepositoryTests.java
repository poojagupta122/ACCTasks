package net.codejava;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class UserRepositoryTests {
	
	@Autowired
	private UserRepository repo;
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Test
	public void testCreateUser()
	{
		User user = new User();
		user.setEmail("rk@gmail.com");
		user.setPassword("9999");
		user.setFirstName("RK");
		user.setLastName("DP");
		
		User savedUSer = repo.save(user);
		
		User existUSer = entityManager.find(User.class, savedUSer.getId());
		
		assertThat(existUSer.getEmail()).isEqualTo(savedUSer.getEmail());
	}
	
	@Test
	public void testFindUserByEmail()
	{
		String email = "rk@gmail.com";
		
		User user = repo.findByEmail(email);
		
		assertThat(user).isNotNull();
	}
	

}
